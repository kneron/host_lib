import ctypes
from time import sleep
import os

BASE_FOLDER = os.path.dirname(__file__)
LIB = ctypes.CDLL(os.path.join(BASE_FOLDER, "libhostkdp.dll"))

import common.constants as constants
def kdp_lib_init():
    """Initialize the host library.

    Returns 0 on success and -1 on failure.
    """
    c_function = LIB.kdp_lib_init
    c_function.argtypes = None
    c_function.restype = ctypes.c_int
    return c_function()

def kdp_lib_start():
    """Start the host library to wait for messages.

    Returns 0 on success and -1 on failure.
    """
    c_function = LIB.kdp_lib_start
    c_function.argtypes = None
    c_function.restype = ctypes.c_int
    return c_function()

def kdp_lib_de_init():
    """Free the resources used by host lib.

    Returns 0 on success and -1 on failure.
    """
    c_function = LIB.kdp_lib_de_init
    c_function.argtypes = None
    c_function.restype = ctypes.c_int
    return c_function()

def kdp_init_log(directory, name):
    """Initialize the host lib internal log.

    Returns 0 on success and -1 on failure.

    Arguments:
        directory: Directory name of the log file (ctypes char_p)
        name: Name of the log file (ctypes char_p)
    """
    c_function = LIB.kdp_init_log
    c_function.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    c_function.restype = ctypes.c_int
    return c_function(directory, name)

def kdp_scan_usb_devices(device_list):
    """Scan all Kneron devices and report a list.

    Returns 0. device_list will be filled on completion.

    Arguments:
        device_list: List of available devices filled by the API (KDPDeviceInfoList double pointer)
    """
    c_function = LIB.kdp_scan_usb_devices
    c_function.argtypes = [ctypes.POINTER(ctypes.POINTER(constants.KDPDeviceInfoList))]
    c_function.restype = ctypes.c_int
    return c_function(device_list)

def kdp_connect_usb_device(scan_index=1):
    """Connect to a Kneron device via 'scan_index'.

    Device ID starts from 1 and can be retrieved through kdp_scan_usb_devices(). If users want
    to connect the first device, just use scan_index = 1.

    Returns device index on success and negative value on failure.

    Arguments:
        scan_index: Device index to connect
    """
    c_function = LIB.kdp_connect_usb_device
    c_function.argtypes = [ctypes.c_int]
    c_function.restype = ctypes.c_int
    return c_function(scan_index)

def kdp_add_dev(device_type, name):
    """Add com device to the host library.

    Returns device index on success and -1 on failure.

    Arguments:
        device_type: Device type, only KDP_USB_DEV is supported now
        name: Name of the UART device (ctypes char_p)
    """
    c_function = LIB.kdp_add_dev
    c_function.argtypes = [ctypes.c_int, ctypes.c_char_p]
    c_function.restype = ctypes.c_int
    return c_function(device_type, name)

def kdp_reset_sys(device_index, reset_mode):
    """Request for system reset.

    Returns 0 on success and error code on failure.

    Arguments:
        device_index: Connected device ID
        reset_mode: Reset mode
            0 - no operation
            1 - reset message protocol
            3 - switch to suspend mode
            4 - switch to active mode
            255 - reset whole system
            256 - system shutdown (RTC)
            0x1000xxxx - reset debug output level
    """
    c_function = LIB.kdp_reset_sys
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32]
    c_function.restype = ctypes.c_int
    return c_function(device_index, reset_mode)

def kdp_report_sys_status(device_index, sfw_id, sbuild_id, sys_status, app_status,
                          nfw_id, nbuild_id):
    """Request for system status.

    Returns 0 on success and -1 on failure. sfw_id, sbuild_id, sys_status, app_status,
    nfw_id, and nbuild_id will be filled with data on completion.

    Arguments:
        device_index: Connected device ID
        sfw_id: Version of the SCPU firmware (ctypes uint32 pointer)
        sbuild_id: Build number of the SCPU firmware (ctypes uint32 pointer)
        sys_status: System status (beta) (ctypes uint16 pointer)
        app_status: Application status (beta) (ctypes uint16 pointer)
        nfw_id: Version of the NCPU firmware (reserved) (ctypes uint32 pointer)
        nbuild_id: Build number of the NCPU firmware (reserved) (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_report_sys_status
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint16),
                           ctypes.POINTER(ctypes.c_uint16), ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, sfw_id, sbuild_id, sys_status, app_status, nfw_id, nbuild_id)

def kdp_get_kn_number(device_index, kn_num):
    """Request for device KN number.

    Returns 0 on success and -1 on failure. kn_num will be filled with data on completion.

    Arguments:
        device_index: Connected device ID
        kn_num: Device KN number (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_get_kn_number
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, kn_num)

def kdp_get_model_info(device_index, from_ddr, r_data):
    """Request for model IDs information for models in DDR or Flash.

    Returns 0 on success and -1 on failure.

    Arguments:
        device_index: Connected device ID
        from_ddr: Query models in DDR (1) or flash (0)
        r_data: Pointer to store model info (ctypes char pointer)
    """
    c_function = LIB.kdp_get_model_info
    c_function.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_char)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, from_ddr, r_data)

def kdp_set_ckey(device_index, ckey, set_status):
    """Set a customized key.

    Returns 0 on success and -1 on failure. set_status will hold status code on completion.

    WARNING!! This API is only for ODM/OEM company.

    Arguments:
        device_index: Connected device ID
        ckey: Key to program
        set_status: Status code (ctypes uint32 pointer)
            0xFFFF: Unsupported command
            0x0: OK
            Ox1: Cannot burn eFuse
            0x2: eFuse protected
    """
    c_function = LIB.kdp_set_ckey
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, ckey, set_status)

def kdp_set_sbt_key(device_index, entry, key, set_status):
    """Set security boot key.

    This should be used for KL720 only. Returns 0 on success and -1 on failure. set_status will
    hold status code on completion.

    Arguments:
        device_index: Connected device ID
        entry: Security key offset (0-13)
        key: Key value
        set_status: Status code (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_set_sbt_key
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, entry, key, set_status)

def kdp_get_crc(device_index, from_ddr, data_buf):
    """Request for CRC info of models in DDR or Flash.

    Returns 0 on success and -1 on failure. data_buf will be filled with CRC info on
    completion.

    Arguments:
        device_index: Connected device ID
        from_ddr: Query models in DDR (1) or flash (0)
        data_buf: CRC data pointer (ctypes char pointer)
    """
    c_function = LIB.kdp_get_crc
    c_function.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_char)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, from_ddr, data_buf)

def kdp_get_nef_model_metadata(model_data, model_size, metadata):
    """Request for metadata of NEF model file.

    Returns 0 on success and -1 on failure. metadata will be filled with NEF
    metadata on completion.

    Arguments:
        model_data: NEF model data (ctypes char pointer)
        model_size: Size of NEF model
        metadata: NEF metadata filled by API (KDPNEFMetadata pointer)
    """
    c_function = LIB.kdp_get_nef_model_metadata
    c_function.argtypes = [ctypes.POINTER(ctypes.c_char), ctypes.c_uint32,
                           ctypes.POINTER(constants.KDPNEFMetadata)]
    c_function.restype = ctypes.c_int
    return c_function(model_data, model_size, metadata)

def kdp_update_fw(device_index, module_id, img_buf, buf_len):
    """Request to update firmware.

    Returns 0 on success and error code on failure.

    Arguments:
        device_index: Connected device ID
        module_id: Module ID of which firmware to be updated (ctypes uint32 pointer)
            0 - no operation
            1 - SCPU module
            2 - NCPU module
        img_buf: Firmware image buffer (ctypes char pointer)
        buf_len: Buffer size
    """
    c_function = LIB.kdp_update_fw
    c_function.argtype = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint32),
                          ctypes.POINTER(ctypes.c_char), ctypes.c_int]
    c_function.restype = ctypes.c_int
    return c_function(device_index, module_id, img_buf, buf_len)

def kdp_update_model(device_index, model_id, model_size, img_buf, buf_len):
    """Request for update model. DEPRECATED

    Returns 0 on success and error code on failure. Also returns the new value of model_id.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        model_id: Model ID to be updated
        model_size: Size of the model
        img_buf: Bin model buffer (fw_info+all_models)
        buf_len: File size
    """
    c_function = LIB.kdp_update_model
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint), ctypes.c_uint,
                           ctypes.c_char_p, ctypes.c_int]
    model_id_p = ctypes.c_uint(model_id)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, ctypes.pointer(model_id_p), model_size, img_buf, buf_len)
    return ret, model_id_p.value

def kdp_update_nef_model(device_index, img_buf, buf_len):
    """Request for update NEF model.

    Returns 0 on success and error code on failure.

    Arguments:
        device_index: Connected device ID
        img_buf: NEF model buffer (ctypes char pointer)
        buf_len: Buffer size
    """
    c_function = LIB.kdp_update_nef_model
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char), ctypes.c_int]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_buf, buf_len)

def kdp_update_spl(device_index, mode, auth_type, spl_size, auth_key,
                   spl_buf, rsp_code, spl_id, spl_build):
    """Request for update spl.

    Returns 0 on success and error code on failure. rsp_code, spl_id, and spl_build
    will be filled with data on completion.

    WARNING!! This API is only for ODM/OEM company.

    Arguments:
        device_index: Connected device ID
        mode: Command mode to be exercised
        auth_type: Authenticator type
        spl_size: Spl FW image file size
        auth_key: Authenticator key (ctypes uint8 pointer)
        spl_buf: Spl FW image buffer (ctypes char pointer)
        rsp_code: Response code (ctypes uint32 pointer)
        spl_id: ID of the spl firmware in device (ctypes uint32 pointer)
        spl_build: Build number of the spl firmware (ctypes.uint32 pointer)
    """
    c_function = LIB.kdp_update_spl
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.c_uint16, ctypes.c_uint16,
                           ctypes.POINTER(ctypes.c_uint8), ctypes.POINTER(ctypes.c_char),
                           ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, mode, auth_type, spl_size, auth_key,
                      spl_buf, rsp_code, spl_id, spl_build)

def kdp_start_sfid_mode(device_index, img_size, thresh, width, height, image_format):
    """Start the user SFID mode with specified threshold and image format.

    Returns 0 on success and error code on failure. img_size will be filled with the read
    image size on completion.

    For FDR application FW only:
        For RGB565/YCbCr422, width MUST be multiple of 2.
        For NIR8, width MUST be multiple of 4.
        For format configuration, refer to IMAGE_FORMAT_XXX in constants.py
        In Mask-FDR mode, unmask FR thresh and mask FR thresh are configured to be the same 
            thresh by kdp_start_sfid_mode() (Please use kdp_sfid_set_float_value() to configure
            specific FR threshold)

    Arguments:
        device_index: Connected device ID
        img_size: Required image file size (ctypes uint32 pointer)
        thresh: Threshold used to match face recognition result (thresh < 1.0)
            0: use default threshold
            < 0: ignore setup threshold
        width: Width of input image
        height: Height of input image
        image_format: Input image format
    """
    c_function = LIB.kdp_start_sfid_mode
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint32), ctypes.c_float,
                           ctypes.c_uint16, ctypes.c_uint16, ctypes.c_uint32]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_size, thresh, width, height, image_format)

def kdp_verify_user_id_generic(device_index, user_id, img_buf, buf_len, mask, res):
    """Perform face recognition by input image with specified output.

    Return 0 on success and error code on failure. user_id, img_buf, mask, and res will be
    filled with data on completion.

    For FDR application FW only.

    Arguments:
        device_index: Connected device ID
        user_id: Found matched user ID (ctypes uint16 pointer)
        img_buf: Image buffer (ctypes char pointer)
        buf_len: Buffer size
        mask: Mask of requested data (ctypes uint16 pointer)
        res: Output result (ctypes char pointer)
            Call kdp_get_res_size() to get result size
    """
    c_function = LIB.kdp_verify_user_id_generic
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint16),
                           ctypes.POINTER(ctypes.c_char), ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint16), ctypes.POINTER(ctypes.c_char)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, user_id, img_buf, buf_len, mask, res)

def kdp_start_reg_user_mode(device_index, user_id, img_index):
    """Start the user register mode.

    Returns 0 on success and -1 on failure.

    For FDR application FW only.
        user_id starts from 1 and is limited by DB MAX configuration.
        img_index is limited by DB MAX configuration.

    Arguments:
        device_index: Connected device ID
        user_id: User ID that will be registered
        img_index: Image index that will be saved
    """
    c_function = LIB.kdp_start_reg_user_mode
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint16, ctypes.c_uint16]
    c_function.restype = ctypes.c_int
    return c_function(device_index, user_id, img_index)

def kdp_get_res_mask(fd, lm, fr, liveness, score):
    """Get result mask with bit flags.

    Returns mask of bit flags.

    For FDR application FW only.

    Arguments:
        fd: Check if face detection output is needed
        lm: Check if landmark detection output is needed
        fr: Check if feature map of face is needed
        liveness: Check if liveness detection output is needed (beta)
        score: Check if recognition score output is needed
    """
    c_function = LIB.kdp_get_res_mask
    c_function.argtypes = [ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
                           ctypes.c_bool]
    c_function.restype = ctypes.c_uint16
    return c_function(fd, lm, fr, liveness, score)

def kdp_get_res_size(fd, lm, fr, liveness, score):
    """Get result size.

    Returns size in bytes.

    For FDR application FW only.

    Arguments:
        fd: Check if face detection output is needed
        lm: Check if landmark detection output is needed
        fr: Check if feature map of face is needed
        liveness: Check if liveness detection output is needed (beta)
        score: Check if recognition score output is needed
    """
    c_function = LIB.kdp_get_res_size
    c_function.argtypes = [ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
                           ctypes.c_bool]
    c_function.restype = ctypes.c_uint32
    return c_function(fd, lm, fr, liveness, score)

def kdp_extract_feature_generic(device_index, img_buf, buf_len, mask, res):
    """Extract the face feature from image with the specified output mask.

    Returns 0 on success and error code on failure. mask and res will be filled on
    completion.

    For FDR application FW only.

    Arguments:
        device_index: Connected device ID
        img_buf: Image buffer (ctypes char pointer)
        buf_len: File size
        mask: Mask of requested data (ctypes uint16 pointer)
            bit 0 - FD result
            bit 1 - LM data
            bit 2 - FM feature map
            bit 3 - liveness
        res: Output data (ctypes char pointer)
            Call kdp_get_res_size() to get result size
    """
    c_function = LIB.kdp_extract_feature_generic
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char), ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint16), ctypes.POINTER(ctypes.c_char)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_buf, buf_len, mask, res)

def kdp_register_user(device_index, user_id):
    """Register the extracted face features to database in device flash.

    Returns 0 on success and error code on failure.

    For FDR application FW only.
        The mentioned feature map can be extracted by kdp_extract_feature_generic().
        user_id must be the same as the one used in kdp_start_reg_user_mode()

    Arguments:
        device_index: Connected device ID
        user_id: User ID that will be registered
    """
    c_function = LIB.kdp_register_user
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32]
    c_function.restype = ctypes.c_int
    return c_function(device_index, user_id)

def kdp_remove_user(device_index, user_id):
    """Removes user from device database.

    Returns 0 on success and error code on failure.

    For FDR application FW only.
        Must be called after kdp_start_sfid_mode() is called.

    Arguments:
        device_index: Connected device ID
        user_id: User ID that will be removed. 0 for all users
    """
    c_function = LIB.kdp_remove_user
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32]
    c_function.restype = ctypes.c_int
    return c_function(device_index, user_id)

def kdp_list_users(device_index, user_id):
    """Test if user is in the device database.

    Returns 0 on success and error code on failure.

    For FDR application FW only.
        Must be called after kdp_start_sfid_mode() is called.

    Arguments:
        device_index: Connected device ID
        user_id: User ID to be listed (starts from 1)
    """
    c_function = LIB.kdp_list_users
    c_function.argtypes = [ctypes.c_int, ctypes.c_int]
    c_function.restype = ctypes.c_int
    return c_function(device_index, user_id)

def kdp_export_db(device_index, p_buf, p_len):
    """Export database image from device.

    Returns 0 on success and error code on failure. p_buf and p_len will be filled on
    completion.

    For FDR application FW only.
        Must be called after kdp_start_sfid_mode() is called.

    Arguments:
        device_index: Connected device ID
        p_buf: Output pointer for exported image (ctypes char double pointer)
        p_len: Database size (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_export_db
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.POINTER(ctypes.c_char)),
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, p_buf, p_len)

def kdp_import_db(device_index, p_buf, p_len):
    """Import customer database image to device.

    Returns 0 on success and error code on failure.

    For FDR application FW only.
        Must be called after kdp_start_sfid_mode() is called.

    Arguments:
        device_index: Connected device ID
        p_buf: Customer's image buffer (ctypes char pointer)
        p_len: Image buffer size
    """
    c_function = LIB.kdp_import_db
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char), ctypes.c_uint32]
    c_function.restype = ctypes.c_int
    return c_function(device_index, p_buf, p_len)

def kdp_register_user_by_fm(device_index, user_id, fm, fm_len):
    """Register user by feature map to device database.

    Returns fm index on success and -1 on failure.

    For FDR application FW only.

    Arguments:
        device_index: Connected device ID
        user_id: User ID to be registered (starts from 1)
        fm: Feature map to register (ctypes char pointer)
        fm_len: Feature map data size in bytes
    """
    c_function = LIB.kdp_register_user_by_fm
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.POINTER(ctypes.c_char),
                           ctypes.c_int]
    c_function.restype = ctypes.c_int
    return c_function(device_index, user_id, fm, fm_len)

def kdp_query_fm_by_user(device_index, fm, user_id, face_id):
    """Query user's feature map from device database.

    Returns fm index on success and error code on failure. fm will be filled with data
    on completion.

    For FDR application FW only.

    Arguments:
        device_index: Connected device ID
        fm: Buffer to store queried feature map data (ctypes char pointer)
        user_id: User ID to be queried (starts from 1)
        face_id: Feature map ID to be queried (starts from 1)
    """
    c_function = LIB.kdp_query_fm_by_user
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char),
                           ctypes.c_uint32, ctypes.c_uint32]
    c_function.restype = ctypes.c_int
    return c_function(device_index, fm, user_id, face_id)

def kdp_fm_compare(user_fm_a, user_fm_b, fm_size):
    """Calculate similarity of two feature points.

    Returns similarity score, with smaller score being more similar. Returns -1 on parameter
    error.

    You must ensure that buffer A and B are of the same size.

    Arguments:
        user_fm_a: Buffer A of user feature map data (ctypes float pointer)
        user_fm_b: Buffer B of user feature map data (ctypes float pointer)
        fm_size: Size of user feature map data
    """
    c_function = LIB.kdp_fm_compare
    c_function.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float),
                           ctypes.c_ulong]
    c_function.restype = ctypes.c_float
    return c_function(user_fm_a, user_fm_b, fm_size)

def kdp_set_db_config(device_index, db_config):
    """Configure database structure.

    Returns 0 on success and error code on failure.

    For FDR application FW only.
        WARNING!! After calling this API, database will be removed and reformatted.

    Arguments:
        device index: Connected device ID
        db_config: Database configuration (KDPDBConfig pointer)
    """
    c_function = LIB.kdp_set_db_config
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(constants.KDPDBConfig)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, db_config)

def kdp_get_db_config(device_index, db_config):
    """Get database configuration structure.

    Returns 0 on success and error code on failure. db_config will be filled with
    data on completion.

    For FDR application FW only.

    Arguments:
        device index: Connected device ID
        db_config: Database configuration (KDPDBConfig pointer)
    """
    c_function = LIB.kdp_set_db_config
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(constants.KDPDBConfig)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, db_config)

def kdp_get_db_index(device_index, db_index):
    """Get current database index.

    Returns 0 on success and error code on failure. db_index will be filled with
    the database index on completion.

    For FDR application FW only.

    Arguments:
        device index: Connected device ID
        db_index: Database index (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_get_db_index
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, db_index)

def kdp_switch_db_index(device_index, db_index):
    """Switch current database index.

    Returns 0 on success and error code on failure.

    For FDR application FW only.

    Arguments:
        device index: Connected device ID
        db_index: Target database index
    """
    c_function = LIB.kdp_switch_db_index
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32]
    c_function.restype = ctypes.c_int
    return c_function(device_index, db_index)

def kdp_set_db_version(device_index, db_version):
    """Set database version number.

    Returns 0 on success and error code on failure.

    For FDR application FW only.

    Arguments:
        device index: Connected device ID
        db_version: Target database version
    """
    c_function = LIB.kdp_set_db_version
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32]
    c_function.restype = ctypes.c_int
    return c_function(device_index, db_version)

def kdp_get_db_version(device_index, db_version):
    """Get database version number.

    Returns 0 on success and error code on failure. db_version will be filled with
    the database version on completion.

    For FDR application FW only.

    Arguments:
        device index: Connected device ID
        db_version: Database version (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_get_db_version
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, db_version)

def kdp_get_db_meta_data_version(device_index, db_meta_data_version):
    """Get database meta data version number for schema confirmation.

    Returns 0 on success and error code on failure. db_meta_data_version will be filled
    with version info on copmletion.

    For FDR application FW only.

    Arguments:
        device_index: Connected device ID
        db_meta_data_version: Database meta data version number (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_get_db_meta_data_version
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, db_meta_data_version)

def kdp_sfid_set_float_value(device_index, value_type, value):
    """Set SFID float configuration value by value type.

    Returns 0 on success and error code on failure.

    For FDR application FW only.
        For configuration value type, refer to SFIDConfigType enum in constants.py.

    Arguments:
        device_index: Connected device ID
        value_type: Required configuration value type
            SFID_FR_UNMASKED_THRESHOLD: threshold used to match unmasked face recognition result
                range: 0.0 < threshold < 1.0
                threshold == 0.0: use default threshold
            SFID_FR_MASKED_THRESHOLD: threshold used to match masked face recognition result
                range: 0.0 < threshold < 1.0
                threshold == 0.0: use default threshold
        value: Configuration value
    """
    c_function = LIB.kdp_sfid_set_float_value
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.c_float]
    c_function.restype = ctypes.c_int
    return c_function(device_index, value_type, value)

def kdp_start_isi_mode(device_index, app_id, return_size, width, height,
                       image_format, rsp_code, buf_size):
    """Start the user isi mode with specified app ID and return data size.

    Returns 0 on success and error code on failure. For image_format, refer to IMAGE_FORMAT_XXX
    in constants.py. rsp_code and buf_size will be filled with data on completion.

    Arguments:
        device_index: Connected device ID
        app_id: Application ID, refer to AppID in constants.py
        return_size: ISI result size
        width: Width of input image
        height: Height of input image
        image_format: Input image format
        rsp_code: Response code (ctypes uint32 pointer)
        buf_size: Depth of image buffer (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_start_isi_mode
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint16,
                           ctypes.c_uint16, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, app_id, return_size, width, height, image_format,
                      rsp_code, buf_size)

def kdp_start_isi_mode_ext(device_index, isi_cfg, cfg_size, rsp_code, buf_size):
    """Start the user ISI mode with the ISI configuration data.

    Returns 0 on success and error code on failure. rsp_code and buf_size will be filled
    with data on completion.

    Arguments:
        device_index: Connected device ID
        isi_cfg: ISI configuration data (ctypes char pointer)
        cfg_size: ISI configuration data size
        rsp_code: Response code (ctypes uint32 pointer)
        buf_size: Depth of image buffer (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_start_isi_mode_ext
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char), ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, isi_cfg, cfg_size, rsp_code, buf_size)

def kdp_start_isi_mode_ext2(device_index, isi_cfg, cfg_size,
                            nef_model_data, model_size, rsp_code, buf_size):
    """Start the user ISI mode and configuration for ISI START command.

    Returns 0 on success and error code on failure. rsp_code and buf_size will be filled
    with data on completion.

    Arguments:
        device_index: Connected device ID.
        isi_cfg: ISI configuration data (ctypes char pointer)
        cfg_size: ISI configuration data size
        nef_model_data: ISI model configuration data (ctypes char pointer)
        model_size: Model data size
        rsp_code: Response code (ctypes uint32 pointer)
        buf_size: Depth of image buffer (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_start_isi_mode_ext2
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char), ctypes.c_int,
                           ctypes.POINTER(ctypes.c_char), ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, isi_cfg, cfg_size, nef_model_data,
                      model_size, rsp_code, buf_size)

def kdp_isi_inference(device_index, img_buf, buf_len, img_id, rsp_code, img_buf_available):
    """Start an inference with an image.

    Before calling this API, host must call kdp_start_isi() to configure the ISI application.
    Returns 0 on success and error code on failure. rsp_code and img_buf_available will
    be filled with data on completion.

    Arguments:
        device_index: Connected device ID
        img_buf: Image buffer (ctypes char pointer)
        buf_len: Image buffer size
        img_id: Sequence ID of the image
        rsp_code: Response code (ctypes uint32 pointer)
        img_buf_available: Number of input image buffers still available (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_isi_inference
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char), ctypes.c_int,
                           ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_buf, buf_len, img_id, rsp_code, img_buf_available)

def kdp_isi_inference_ext(device_index, img_buf, img_header,
                          header_len, rsp_code, img_buf_available):
    """Start an inference with an image and image header.

    Before calling this API, host must call kdp_start_isi() to configure the ISI application.
    Returns 0 on success and error code on failure. rsp_code and img_buf_available will
    be filled with data on completion.

    Arguments:
        device_index: Connected device ID
        img_buf: Image buffer (ctypes char pointer)
        img_header: Image information (KDPISIImageHeader pointer)
        header_len: Header size
        rsp_code: Response code (ctypes uint32 pointer)
        img_buf_available: Number of input image buffers still available (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_isi_inference_ext
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char),
                           ctypes.POINTER(constants.KDPISIImageHeader),
                           ctypes.c_uint16, ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_buf, img_header, header_len, rsp_code, img_buf_available)

def kdp_isi_retrieve_res(device_index, img_id, rsp_code, r_size, r_data):
    """Request for getting inference results.

    Returns 0 on success and error code on failure. rsp_code, r_size, and r_data will
    be filled with data on completion.

    Arguments:
        device_index: Connected device ID
        img_id: Sequence ID to get inference results of an image with that ID
        rsp_code: Response code (ctypes uint32 pointer)
        r_size: Inference data size (ctypes uint32 pointer)
        r_data: Inference result data (ctypes char pointer)
    """
    c_function = LIB.kdp_isi_retrieve_res
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_char)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_id, rsp_code, r_size, r_data)

def kdp_isi_config(device_index, model_id, param, rsp_code):
    """Configure the model for the supported model ID.

    Returns 0 on success and error code on failure. rsp_code will be filled with data
    on completion.

    Arguments:
        device_index: Connected device ID
        model_id: Model ID to run image inference
        param: Parameter needed for the model
        rsp_code: Response code from ISI command handler on device (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_isi_config
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, model_id, param, rsp_code)

def kdp_end_isi(device_index):
    """Request for ending ISI mode.

    Returns 0 on success and error code on failure

    Arguments:
        device_index: Connected device ID
    """
    c_function = LIB.kdp_end_isi
    c_function.argtypes = [ctypes.c_int]
    c_function.restype = ctypes.c_int
    return c_function(device_index)

def kdp_jpeg_enc_config(device_index, img_seq, width, height, image_format, quality):
    """Configure host for JPEG encoding.

    Returns 0 on success and error code on failure.

    For KL720 only.

    Arguments:
        device_index: Connected device ID
        img_seq: Image number
        width: Width of image
        height: Height of image
        image_format: Input YUV image format
        quality: JPEG encoding quality (0-100), 70-75 is recommended
    """
    c_function = LIB.kdp_jpeg_enc_config
    c_function.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                           ctypes.c_int, ctypes.c_int]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_seq, width, height, image_format, quality)

def kdp_jpeg_enc(device_index, img_seq, in_img_buf, in_img_len, out_img_buf, out_img_len):
    """Start JPEG encoding.

    Returns 0 on success and error code on failure. out_img_buf and out_img_len will be
    filled with data on completion.

    For KL720 only.

    Arguments:
        device_index: Connected device ID
        img_seq: Image number
        in_img_buf: Input YUV image buffer (ctypes uint8 pointer)
        in_img_len: Input image size in bytes
        out_img_buf: Encoding output JPEG buffer addres in SCPU (not host address)
            (ctypes uint32 pointer)
        out_img_len: Encoding output valid length (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_jpeg_enc
    c_function.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_uint8),
                           ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_seq, in_img_buf, in_img_len, out_img_buf, out_img_len)

def kdp_jpeg_enc_retrieve_res(device_index, img_seq, rsp_code, r_size, r_data):
    """Retrieve JPEG encoding output.

    Returns 0 on success and error code on failure. rsp_code, r_size, and r_data will be
    filled with data on completion.

    For KL720 only.

    Arguments:
        device_index: Connected device ID
        img_seq: Image number
        rsp_code: Response code (ctypes uint32 pointer)
        r_size: Result size (ctypes uint32 pointer)
        r_data: Result data buffer (host address) (ctypes char pointer)
    """
    c_function = LIB.kdp_jpeg_enc_retrieve_res
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_char)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_seq, rsp_code, r_size, r_data)

def kdp_jpeg_dec_config(device_index, img_seq, width, height, image_format, length):
    """Configure host for JPEG decoding.

    Returns 0 on success and error code on failure.

    For KL720 only.

    Arguments:
        device_index: Connected device ID
        img_seq: Image number
        width: Width of decoded output image
        height: Height of decoded output image
        image_format: Decoded output YUV image format
        length: JPEG valid length in bytes
    """
    c_function = LIB.kdp_jpeg_dec_config
    c_function.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                           ctypes.c_int, ctypes.c_int]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_seq, width, height, image_format, length)

def kdp_jpeg_dec(device_index, img_seq, in_img_buf, in_img_len, out_img_buf, out_img_len):
    """Start JPEG decoding.

    Returns 0 on success and error code on failure. out_img_buf and out_img_len will be
    filled with data on completion.

    For KL720 only.

    Arguments:
        device_index: Connected device ID
        img_seq: Image number
        in_img_buf: Input JPEG image buffer (ctypes uint8 pointer)
        in_img_len: Input image size in bytes
        out_img_buf: Encoding output YUV buffer addres in SCPU (not host address)
            (ctypes uint32 pointer)
        out_img_len: Encoding output valid length (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_jpeg_dec
    c_function.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_uint8),
                           ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_seq, in_img_buf, in_img_len, out_img_buf, out_img_len)

def kdp_jpeg_dec_retrieve_res(device_index, img_seq, rsp_code, r_size, r_data):
    """Retrieve JPEG decoding output.

    Returns 0 on success and error code on failure. rsp_code, r_size, and r_data will be
    filled with data on completion.

    For KL720 only.

    Arguments:
        device_index: Connected device ID
        img_seq: Image number
        rsp_code: Response code (ctypes uint32 pointer)
        r_size: Result size (ctypes uint32 pointer)
        r_data: Result data buffer (host address) (ctypes char pointer)
    """
    c_function = LIB.kdp_jpeg_dec_retrieve_res
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_char)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_seq, rsp_code, r_size, r_data)

def kdp_start_dme(device_index, model_size, data, data_size, ret_size, img_buf, buf_len):
    """Request for starting dynamic model execution. DEPRECATED

    Returns 0 on success and error code on failure. Also returns the new value of ret_size.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        model_size: Size of inference model.
        data: Firmware setup data
        data_size: Setup data size.
        ret_size: Returned model size.
        img_buf: Model file buffer.
        buf_len: File size.
    """
    c_function = LIB.kdp_start_dme
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint, ctypes.c_char_p, ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint), ctypes.c_char_p, ctypes.c_int]
    ret_size_p = ctypes.c_uint(ret_size)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, model_size, data, data_size, ctypes.pointer(ret_size_p),
                     img_buf, buf_len)
    return ret, ret_size_p.value

def kdp_start_dme_ext(device_index, nef_model_data, model_size, ret_size):
    """Request for starting dynamic model execution.

    Returns 0 on success and error code on failure. ret_size will be filled with data
    on completion.

    Only support NEF model file with 1 model. Composed model set is not supported.

    Arguments:
        device_index: Connected device ID
        nef_model_data: NEF model data (ctypes char pointer)
        model_size: Size of NEF model
        ret_size: Returned model size (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_start_dme_ext
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char), ctypes.c_uint32,
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, nef_model_data, model_size, ret_size)

def kdp_dme_configure(device_index, data, data_size, ret_model_id):
    """Request for configuring DME.

    Returns 0 on success and error code on failure. ret_model_id will be filled with
    data on completion.

    Arguments:
        device_index: Connected device ID
        data: Inference setup data (ctypes char pointer)
        data_size: Setup data size
        ret_model_id: Return value of model ID for this configuration (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_dme_configure
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char), ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, data, data_size, ret_model_id)

def kdp_dme_inference(device_index, img_buf, buf_len, inf_size, res_flag, inf_res, mode, model_id):
    """Do inference with provided model.

    Before calling this API, host must call kdp_start_dme() and kdp_dme_configure() to configure
    the DME model. Returns 0 on success and error code on failure. res_flag and inf_res will be
    filled with data on completion.

    Arguments:
        device_index: Connected device ID
        img_buf: Image buffer (ctypes char pointer)
        buf_len: Image buffer size
        inf_size: Size of inference result in DME 'serial mode' (ctypes uint32 pointer)
            Session ID of image in DME 'async mode'
        res_flag: Indicate whether result is requested and available (ctypes bool pointer)
        inf_res: Returned inference result (ctypes char pointer)
        mode: Running mode, 0 for 'serial' and 1 for 'async'
        model_id: Model ID for this configuration
    """
    c_function = LIB.kdp_dme_inference
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char), ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_bool),
                           ctypes.POINTER(ctypes.c_char), ctypes.c_uint16, ctypes.c_uint16]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_buf, buf_len, inf_size, res_flag, inf_res, mode, model_id)

def kdp_dme_retrieve_res(device_index, addr, length, inf_res):
    """Request for retrieving DME result.

    Returns 0 on success and error code on failure. inf_res will be filled with result
    data on completion.

    Arguments:
        device_index: Connected device ID
        addr: DDR address to retrieve
        length: Size of data to retrieve
        inf_res: Result data (ctypes char pointer)
    """
    c_function = LIB.kdp_dme_retrieve_res
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.c_int,
                           ctypes.POINTER(ctypes.c_char)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, addr, length, inf_res)

def kdp_dme_get_status(device_index, ssid, status, inf_size, inf_res):
    """Request for getting DME inference status.

    Returns 0 on success and error code on failure. ssid, status, inf_size, and inf_res
    will be filled with data on completion.

    Arguments:
        device_index: Connected device ID
        ssid: SSID to get inference status (ctypes uint16 pointer)
        status: Inference status, 0 for not ready and 1 for ready (ctypes uint16 pointer)
        inf_size: Inference data size (ctypes uint32 pointer)
        inf_res: Inference result data (ctypes char pointer)
    """
    c_function = LIB.kdp_dme_get_status
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint16),
                           ctypes.POINTER(ctypes.c_uint16), ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_char)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, ssid, status, inf_size, inf_res)

def kdp_end_dme(device_index):
    """Request for ending DME mode.

    Returns 0 on success and error code on failure.

    Arguments:
        device_index: Connected device ID
    """
    c_function = LIB.kdp_end_dme
    c_function.argtypes = [ctypes.c_int]
    c_function.restype = ctypes.c_int
    return c_function(device_index)

def kdp_start_hico_mode(device_index, hico_cfg, cfg_size, rsp_code, buf_size):
    """Start HICO (Host/camera IN Companion OUT) mode with configuration.

    Returns 0 on success and error code on failure. rsp_code and buf_size will be filled
    with data on completion.

    Arguments:
        device_index: Connected device ID
        hico_cfg: HICO configuration data (ctypes char pointer)
        cfg_size: HICO configuration data size
        rsp_code: Response code (ctypes uint32 pointer)
        buf_size: Max buffer size for response and return data (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_start_hico_mode
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char), ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, hico_cfg, cfg_size, rsp_code, buf_size)

def kdp_hico_send_image(device_index, img_buf, buf_len, img_id, rsp_code):
    """Send an input image.

    Host must call kdp_start_hico_mode() before calling this functions. Returns 0 on success
    and error code on failure. rsp_code will be filled with data on completion.

    Arguments:
        device_index: Connected device ID
        img_buf: Image buffer (ctypes char pointer)
        buf_len: Image buffer size
        img_id: Image number
        rsp_code: Response code (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_hico_send_image
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char), ctypes.c_int,
                           ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_buf, buf_len, img_id, rsp_code)

def kdp_hico_retrieve_res(device_index, img_id, rsp_code, r_size, r_data):
    """Retrieve HICO image inference results.

    Returns 0 on success and error code on failure. rsp_code, r_size, and r_data will be
    filled with data on completion.

    Arguments:
        device_index: Connected device ID
        img_seq: Image number
        rsp_code: Response code (ctypes uint32 pointer)
        r_size: Result size (ctypes uint32 pointer)
        r_data: Result data buffer (ctypes char pointer)
    """
    c_function = LIB.kdp_hico_retrieve_res
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32),
                           ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_char)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, img_id, rsp_code, r_size, r_data)

def kdp_end_hico(device_index, param, rsp_code):
    """Request for ending HICO mode.

    Returns 0 on success and error code on failure. rsp_code will be filled with data
    on completion.

    Arguments:
        device_index: Connected device ID
        param: Input parameter
        rsp_code: Response code (ctypes uint32 pointer)
    """
    c_function = LIB.kdp_end_hico
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32)]
    c_function.restype = ctypes.c_int
    return c_function(device_index, param, rsp_code)

def read_file_to_buf(buf, fn, nlen):
    """Read file to buffer.

    Returns 0 on success and -1 on error.

    Arguments:
        buf: Buffer to hold data (ctypes char pointer)
        fn: Name of file to read (ctypes char_p)
        nlen: Length of file to read
    """
    c_function = LIB.read_file_to_buf
    c_function.argtypes = [ctypes.POINTER(ctypes.c_char), ctypes.c_char_p, ctypes.c_int]
    c_function.restype = ctypes.c_int
    return c_function(buf, fn, nlen)

def kdp_mp_gpio_set(device_index, pin, value):
    """Set GPIO.

    Returns 0 on success and -1 on error.

    For KL720 only.

    Arguments:
        device_index: Connected device ID
        pin: GPIO pin index (0-31)
        value: Value to set (0 or non-zero)
    """
    c_function = LIB.kdp_mp_gpio_set
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32]
    c_function.restype = ctypes.c_int
    return c_function(device_index, pin, value)
