import ctypes
from time import sleep
import os

BASE_FOLDER = os.path.dirname(__file__)
LIB = ctypes.CDLL(os.path.join(BASE_FOLDER, "libhostkdp.so"))

def read_file_to_buf(buf, fn, nlen):
    c_function = LIB.read_file_to_buf
    c_function.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
    c_function.restype = ctypes.c_int
    return c_function(buf, fn.encode(), nlen)

def kdp_lib_init():
    """Initialize the host library.

    Returns 0 on success and -1 on failure.
    """
    c_function = LIB.kdp_lib_init
    c_function.argtypes = None
    c_function.restype = ctypes.c_int
    return c_function()

def kdp_lib_start():
    """Start the host library to wait for messages.

    Returns 0 on success and -1 on failure.
    """
    c_function = LIB.kdp_lib_start
    c_function.argtypes = None
    c_function.restype = ctypes.c_int
    return c_function()

def kdp_lib_de_init():
    """Free the resources used by host lib.

    Returns 0 on success and -1 on failure.
    """
    c_function = LIB.kdp_lib_de_init
    c_function.argtypes = None
    c_function.restype = ctypes.c_int
    return c_function()

def kdp_init_log(directory, name):
    """Initialize the host lib internal log.

    Returns 0 on success and -1 on failure.

    Arguments:
        directory: Directory name of the log file
        name: Name of the log file
    """
    c_function = LIB.kdp_init_log
    c_function.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    c_function.restype = ctypes.c_int
    return c_function(directory.encode(), name.encode())

def kdp_add_dev(device_type, name):
    """Add com device to the host library.

    Returns device index on success and -1 on failure.

    Arguments:
        device_type: Device type, only KDP_UART_DEV is supported now
        name: Name of the UART device
    """
    c_function = LIB.kdp_add_dev
    c_function.argtypes = [ctypes.c_int, ctypes.c_char_p]
    c_function.restype = ctypes.c_int
    return c_function(device_type, name.encode())

def kdp_reset_sys(device_index, reset_mode):
    """Request for system reset.

    Returns 0 on success and error code on failure.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        reset_mode: Reset mode.
            0 - no operation
            1 - reset message protocol
            3 - switch to suspend mode
            4 - switch to activer mode
            255 - reset whole system
            256 - system shutdown (RTC)
            0x1000xxxx - reset debug output level
    """
    c_function = LIB.kdp_reset_sys
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint]
    c_function.restype = ctypes.c_int
    return c_function(device_index, reset_mode)

def kdp_report_sys_status(device_index, sfw_id, sbuild_id, sys_status, app_status,
                          nfw_id, nbuild_id):
    """Request for system status.

    Returns 0 on success and -1 on failure. Also returns the new values of sfw_id, sbuild_id,
    sys_status, app_status, nfw_id, and nbuild_id.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        sfw_id: ID of the SCPU firmware in device.
        sbuild_id: Build number of the SCPU firmware in device
        sys_status: System status
        app_status: Application status
        nfw_id: ID of the NCPU firmware in device
        nbuild_id: Build number of the NCPU firmware in device
    """
    c_function = LIB.kdp_report_sys_status
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint),
                           ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint),
                           ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint),
                           ctypes.POINTER(ctypes.c_uint)]
    sfw_id_p = ctypes.c_uint(sfw_id)
    sbuild_id_p = ctypes.c_uint(sbuild_id)
    sys_status_p = ctypes.c_uint(sys_status)
    app_status_p = ctypes.c_uint(app_status)
    nfw_id_p = ctypes.c_uint(nfw_id)
    nbuild_id_p = ctypes.c_uint(nbuild_id)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, ctypes.pointer(sfw_id_p), ctypes.pointer(sbuild_id_p),
                     ctypes.pointer(sys_status_p), ctypes.pointer(app_status_p),
                     ctypes.pointer(nfw_id_p), ctypes.pointer(nbuild_id_p))
    return (ret, sfw_id_p.value, sbuild_id_p.value, sys_status_p.value, app_status_p.value,
            nfw_id_p.value, nbuild_id_p.value)

def kdp_update_fw(device_index, module_id, img_buf, buf_len):
    """Request for update firmware.

    Returns 0 on success and error code on failure. Also returns the new value of module_id.


    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        module_id: Module ID of which firmware to be updated
            0 - no operation
            1 - SCPU module
            2 - NCPU module
        img_buf: Firmware image buffer
        buf_len: File size
    """
    c_function = LIB.kdp_update_fw
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint), ctypes.c_char_p,
                           ctypes.c_int]
    module_id_p = ctypes.c_uint(module_id)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, ctypes.pointer(module_id_p), img_buf, buf_len)
    return ret, module_id_p.value

def kdp_update_model(device_index, model_id, model_size, img_buf, buf_len):
    """Request for update model.

    Returns 0 on success and error code on failure. Also returns the new value of model_id.


    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        model_id: Model ID to be updated
        model_size: Size of the model
        img_buf: Firmware image buffer
        buf_len: File size
    """
    c_function = LIB.kdp_update_model
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint), ctypes.c_uint,
                           ctypes.c_char_p, ctypes.c_int]
    model_id_p = ctypes.c_uint(model_id)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, ctypes.pointer(model_id_p), model_size, img_buf, buf_len)
    return ret, model_id_p.value

def kdp_update_spl(device_index, mode, auth_type, spl_size, auth_key,
                   spl_buf, rsp_code, spl_id, spl_build):
    """Request for update spl.

    Returns 0 on success and error code on failure. Also returns the new values of auth_key,
    rsp_code, spl_id, and spl_build.


    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        mode: Comand mode to be exercised
        auth_type: Authenticator type
        spl_size: SPL file size
        auth_key: Authenticator key
        spl_buf: SPL firmware image
        rsp_code:
        spl_id: ID of the SPL firmware in device (post command execution)
        spl_build: Build number of the SPL firmware in device
    """
    c_function = LIB.kdp_update_spl
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint,
                           ctypes.POINTER(ctypes.c_uint), ctypes.c_char_p,
                           ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint),
                           ctypes.POINTER(ctypes.c_uint)]
    auth_key_p = ctypes.c_uint(auth_key)
    rsp_code_p = ctypes.c_uint(rsp_code)
    spl_id_p = ctypes.c_uint(spl_id)
    spl_build_p = ctypes.c_uint(spl_build)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, mode, auth_type, spl_size, ctypes.pointer(auth_key_p),
                     spl_buf, ctypes.pointer(rsp_code_p), ctypes.pointer(spl_id_p),
                     ctypes.pointer(spl_build_p))
    return ret, auth_key_p.value, rsp_code_p.value, spl_id_p.value, spl_build_p.value

def kdp_start_sfid_mode(device_index, img_size, thresh, width, height, image_format):
    """Start the user SFID mode with specified threshold and image format.

    Returns 0 on success and error code on failure. Also returns the new value of img_size.


    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        img_size: Required image file size.
        thresh: Threshold used to match face recognition result. If 0, the default threshold
            is used.
        width: Width of the input image.
        height: Height of the input image.
        image_format: Input image format.
    """
    c_function = LIB.kdp_start_sfid_mode
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint), ctypes.c_float,
                           ctypes.c_uint, ctypes.c_uint, ctypes.c_uint]
    img_size_p = ctypes.c_uint(img_size)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, ctypes.pointer(img_size_p), thresh, width, height, image_format)
    return ret, img_size_p.value

def kdp_verify_user_id_generic(device_index, user_id, img_buf, buf_len, mask, res):
    """Extract the face feature from input image, compare it with database, and return the
       matched user ID and face analysis related result.

    Returns 0 on success and error code on failure. Also returns the new values of user_id and
    mask. FD/LM/FR/LV result size: please refer to model_res.h.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        user_id: Matched user ID in database will be returned.
        img_buf: Image buffer.
        buf_len: File size.
        mask: Indicated the requested and responsed flags.
            bit 0 - FD result
            bit 1 - LM data
            bit 2 - FM feature map
            bit 3 - liveness
        res: Contains all the related result.
    """
    c_function = LIB.kdp_verify_user_id_generic
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint), ctypes.c_char_p,
                           ctypes.c_int, ctypes.POINTER(ctypes.c_uint), ctypes.c_char_p]
    user_id_p = ctypes.c_uint(user_id)
    mask_p = ctypes.c_uint(mask)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, ctypes.pointer(user_id_p), img_buf, buf_len,
                     ctypes.pointer(mask_p), res)
    return ret, user_id_p.value, mask_p.value

def kdp_start_reg_user_mode(device_index, user_id, img_index):
    """Start the user register mode.

    Returns 0 on success and -1 on failure.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        user_id: User ID that will be registered.
        img_index: Image index that will be saved (a user could have 5 images).
    """
    c_function = LIB.kdp_start_reg_user_mode
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint, ctypes.c_uint]
    c_function.restype = ctypes.c_int
    return c_function(device_index, user_id, img_index)

def kdp_get_res_mask(fd, lm, fr, liveness):
    """Get lw3D result mask."""
    c_function = LIB.kdp_get_res_mask
    c_function.argtypes = [ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool]
    c_function.restype = ctypes.c_uint
    return c_function(fd, lm, fr, liveness)

def kdp_get_res_size(fd, lm, fr, liveness):
    """Get lw3D result size."""
    c_function = LIB.kdp_get_res_size
    c_function.argtypes = [ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool]
    c_function.restype = ctypes.c_uint
    return c_function(fd, lm, fr, liveness)

def kdp_extract_feature_generic(device_index, img_buf, buf_len, mask, res):
    """Extract the face feature from input image, save it in the device, and return the
       face detection and face recognition result.

    Returns 0 on success and error code on failure. Also returns the new value of mask.
    FD/LM/FR/LV result size: please refer to model_res.h.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        img_buf: Image buffer.
        buf_len: File size.
        mask: Indicated the requested and responsed flags.
            bit 0 - FD result
            bit 1 - LM data
            bit 2 - FM feature map
            bit 3 - liveness
        res: Contains all the related result.
    """
    c_function = LIB.kdp_extract_feature_generic
    c_function.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint), ctypes.c_char_p]
    mask_p = ctypes.c_uint(mask)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, img_buf, buf_len, ctypes.pointer(mask_p), res)
    return ret, mask_p.value

def kdp_register_user(device_index, user_id):
    """Register the face features to device database.

    Before calling this API, host must have called kdp_extract_feature at least once
    successfully. Otherwise, no features could be saved. Returns 0 on success and error
    code on failure.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        user_id: User ID that will be registered. Must be the same as the kdp_start_reg_user_mode.
    """
    c_function = LIB.kdp_register_user
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint]
    c_function.restype = ctypes.c_int
    return c_function(device_index, user_id)

def kdp_remove_user(device_index, user_id):
    """Removes user from device database.

    It needs to be called after start lw3d mode or start verify mode. Returns 0 on success
    and error code on failure.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        user_id: User ID that will be removed. 0 for all users
    """
    c_function = LIB.kdp_remove_user
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint]
    c_function.restype = ctypes.c_int
    return c_function(device_index, user_id)

def kdp_start_lw3d_mode(device_index, rgb_size, nir_size, rgb_thresh, nir_thresh, rgb_width,
                        rgb_height, nir_width, nir_height, rgb_fmt, nir_fmt):
    """Start the lightweight 3D mode with specified threshold and image format.

    Returns 0 on success and error code on failure. Also returns the new values of rgb_size and
    nir_size.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        rgb_size: Required rgb image file size will be returned.
        nir_size: Required nir image file size will be returned.
        rgb_thresh: Threshold used to match RGB face recognition result. If 0, the default
            threshold is used.
        nir_thresh: Threshold used to match NIR face recognition result. If 0, the default
            threshold is used.
        rgb_width: Width of RGB image.
        rgb_height: Height of RGB image.
        nir_width: Width of NIR image.
        nir_height: Height of NIR image.
        rgb_fmt: Format of RGB image.
        nir_fmt: Format of NIR image.
    """
    c_function = LIB.kdp_start_lw3d_mode
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint),
                           ctypes.POINTER(ctypes.c_uint), ctypes.c_float, ctypes.c_float,
                           ctypes.c_uint, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint,
                           ctypes.c_uint, ctypes.c_uint]
    rgb_size_p = ctypes.c_uint(rgb_size)
    nir_size_p = ctypes.c_uint(nir_size)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, ctypes.pointer(rgb_size_p), ctypes.pointer(nir_size_p),
                     rgb_thresh, nir_thresh, rgb_width, rgb_height, nir_width, nir_height,
                     rgb_fmt, nir_fmt)
    return ret, rgb_size_p.value, nir_size_p.value

def kdp_get_lw3d_res_mask(fd, lm, fr, nir_fd, nir_lm, nir_fr, liveness):
    """Get the lw3D result mask."""
    c_function = LIB.kdp_get_lw3d_res_mask
    c_function.argtypes = [ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
                           ctypes.c_bool, ctypes.c_bool, ctypes.c_bool]
    c_function.restype = ctypes.c_uint
    return c_function(fd, lm, fr, nir_fd, nir_lm, nir_fr, liveness)

def kdp_get_lw3d_res_size(fd, lm, fr, nir_fd, nir_lm, nir_fr, liveness):
    """Get the lw3D result size."""
    c_function = LIB.kdp_get_lw3d_res_size
    c_function.argtypes = [ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
                           ctypes.c_bool, ctypes.c_bool, ctypes.c_bool]
    c_function.restype = ctypes.c_uint
    return c_function(fd, lm, fr, nir_fd, nir_lm, nir_fr, liveness)

def kdp_extract_lw3d_feature_generic(device_index, img_buf, buf_len, img_buf_nir, buf_len_nir,
                                     mask, res):
    """Extract the face feature from input RGB/NIR image, save it in device, and return
       the face analysis related result if required.

    Returns 0 on success and error code on failure. Also returns the new value of mask.
    FD/LM/FR/LV result size: please refer to model_res.h.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        img_buf: RGB image buffer.
        buf_len: RGB file size.
        img_buf_nir: NIR image buffer.
        buf_len_nir: NIR file size.
        mask: Indicated the requested and responsed flags.
            bit 0 - FD result
            bit 1 - FM feature map
            bit 2 - LM data
            bit 4 - NIR FD result
            bit 5 - NIR feature map
            bit 6 - NIR LM data
            bit 8 - final liveness
        res: Contains all the related result.
    """
    c_function = LIB.kdp_extract_lw3d_feature_generic
    c_function.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p,
                           ctypes.c_int, ctypes.POINTER(ctypes.c_uint), ctypes.c_char_p]
    mask_p = ctypes.c_uint(mask)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, img_buf, buf_len, img_buf_nir, buf_len_nir,
                     ctypes.pointer(mask_p), res)
    return ret, mask_p.value

def kdp_verify_lw3d_image_generic(device_index, user_id, img_buf, buf_len, img_buf_nir,
                                  buf_len_nir, mask, res):
    """Extract the face feature from input RGB/NIR image, compare it with database, and return
       the matched user ID and the face analysis related result.

    Returns 0 on success and error code on failure. Also returns the new values of user_id and
    mask. FD/LM/FR/LV result size: please refer to model_res.h.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        user_id: Matched user ID in database will be returned
        img_buf: RGB image buffer.
        buf_len: RGB file size.
        img_buf_nir: NIR image buffer.
        buf_len_nir: NIR file size.
        mask: Indicated the requested and responsed flags.
            bit 0 - FD result
            bit 1 - FM feature map
            bit 2 - LM data
            bit 4 - NIR FD result
            bit 5 - NIR feature map
            bit 6 - NIR LM data
            bit 8 - final liveness
        res: Contains all the related result.
    """
    c_function = LIB.kdp_verify_lw3d_image_generic
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint), ctypes.c_char_p,
                           ctypes.c_int, ctypes.c_char_p, ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint), ctypes.c_char_p]
    user_id_p = ctypes.c_uint(user_id)
    mask_p = ctypes.c_uint(mask)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, ctypes.pointer(user_id_p), img_buf, buf_len, img_buf_nir,
                     buf_len_nir, ctypes.pointer(mask_p), res)
    return ret, user_id_p.value, mask_p.value

def kdp_fm_compare(user_fm_a, user_fm_b, fm_size):
    """Calculate similarity of two feature points.

    Returns similarity score, with smaller score being more similar. Returns -1 on parameter
    error. Also returns the new values of user_fm_a and user_fm_b.

    Arguments:
        user_fm_a: Buffer A of user feature map data.
        user_fm_b: Buffer B of user feature map data.
        fm_size: Size of user feature map data.
    """
    c_function = LIB.kdp_fm_compare
    c_function.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float),
                           ctypes.c_int]
    user_fm_a_p = ctypes.c_uint(user_fm_a)
    user_fm_b_p = ctypes.c_uint(user_fm_b)
    c_function.restype = ctypes.c_float
    ret = c_function(ctypes.pointer(user_fm_a_p), ctypes.pointer(user_fm_b_p), fm_size)
    return ret, user_fm_a_p.value, user_fm_b_p.value

def kdp_start_isi_mode(device_index, app_id, return_size, width, height,
                       image_format, rsp_code, buf_size):
    """Start the user isi mode with specified app id and return data size.

    Returns 0 on success and error code on failure. Also returns the new values of rsp_code
    and buf_size.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        app_id:
        return_size:
        width: Width of input image.
        height: Height of input image.
        image_format: Format of input image.
        rsp_code:
        buf_size: Depth of image buffer will be returned.
    """
    c_function = LIB.kdp_start_isi_mode
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint,
                           ctypes.c_uint, ctypes.c_uint, ctypes.POINTER(ctypes.c_uint),
                           ctypes.POINTER(ctypes.c_uint)]
    rsp_code_p = ctypes.c_uint(rsp_code)
    buf_size_p = ctypes.c_uint(buf_size)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, app_id, return_size, width, height, image_format,
                     ctypes.pointer(rsp_code_p), ctypes.pointer(buf_size_p))
    return ret, rsp_code_p.value, buf_size_p.value

def kdp_isi_inference(device_index, img_buf, buf_len, img_id, rsp_code, img_buf_available):
    """Start an inference with an image.

    Before calling this API, host must call kdp_start_isi to configure the isi application.
    Returns 0 on success and error code on failure. Also returns the new values of rsp_code and
    img_buf_available.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        img_buf: Image buffer.
        buf_len: File size.
        img_id: Sequence ID of the image.
        rsp_code:
        img_buf_available: Number of image buffers still available for input.
    """
    c_function = LIB.kdp_isi_inference
    c_function.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_uint,
                           ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint)]
    rsp_code_p = ctypes.c_uint(rsp_code)
    img_buf_available_p = ctypes.c_uint(img_buf_available)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, img_buf, buf_len, img_id, ctypes.pointer(rsp_code_p),
                     ctypes.pointer(img_buf_available_p))
    return ret, rsp_code_p.value, img_buf_available_p.value

def kdp_isi_retrieve_res(device_index, img_id, rsp_code, r_size, r_data):
    """Request for getting an inference results.

    Returns 0 on success and error code on failure. Also returns the new values of rsp_code
    and r_size.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        img_id: Sequence ID to get inference results of an image with that ID
        rsp_code:
        r_size: Inference data size
        r_data: Inference result data
    """
    c_function = LIB.kdp_isi_retrieve_res
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint, ctypes.POINTER(ctypes.c_uint),
                           ctypes.POINTER(ctypes.c_uint), ctypes.c_char_p]
    rsp_code_p = ctypes.c_uint(rsp_code)
    r_size_p = ctypes.c_uint(r_size)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, img_id, ctypes.pointer(rsp_code_p),
                     ctypes.pointer(r_size_p), r_data)
    return ret, rsp_code_p.value, r_size_p.value

def kdp_start_dme(device_index, model_size, data, data_size, ret_size, img_buf, buf_len):
    """Request for starting dynamic model execution.

    Returns 0 on success and error code on failure. Also returns the new value of ret_size.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        model_size: Size of inference model.
        data: Firmware setup data
        data_size: Setup data size.
        ret_size: Returned model size.
        img_buf: Model file buffer.
        buf_len: File size.
    """
    c_function = LIB.kdp_start_dme
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint, ctypes.c_char_p, ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint), ctypes.c_char_p, ctypes.c_int]
    ret_size_p = ctypes.c_uint(ret_size)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, model_size, data, data_size, ctypes.pointer(ret_size_p),
                     img_buf, buf_len)
    return ret, ret_size_p.value

def kdp_dme_configure(device_index, data, data_size, ret_model_id):
    """Request for configuring dme.

    Returns 0 on success and error code on failure. Also returns the new value of ret_model_id.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        data: Inference setup data.
        data_size: Setup data size.
        ret_model_id: Return value of model ID for this configuration.
    """
    c_function = LIB.kdp_dme_configure
    c_function.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint)]
    ret_model_id_p = ctypes.c_uint(ret_model_id)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, data, data_size, ctypes.pointer(ret_model_id_p))
    return ret, ret_model_id_p.value

def kdp_dme_inference(device_index, img_buf, buf_len, inf_size, res_flag, inf_res, mode, model_id):
    """Callling KL520 to do inference with provided model.

    Before calling this API, host must call kdp_start_dme and kdp_dme_configure to configurea
    the dme model. Returns 0 on success and error code on failure. Also returns the new values of
    inf_size and res_flag.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        img_buf: Image buffer.
        buf_len: File size.
        inf_size: Size of inference result.
        res_flag: Indicate whether result is requested and available.
        inf_res: Contains the returned inference result.
        mode: Normal or async mode.
        model_id: Model ID for this configuration.
    """
    c_function = LIB.kdp_dme_inference
    c_function.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int,
                           ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_bool),
                           ctypes.c_char_p, ctypes.c_uint, ctypes.c_uint]
    inf_size_p = ctypes.c_uint(inf_size)
    res_flag_p = ctypes.c_bool(res_flag)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, img_buf, buf_len, ctypes.pointer(inf_size_p),
                     ctypes.pointer(res_flag_p), inf_res, mode, model_id)
    return ret, inf_size_p.value, res_flag_p.value

def kdp_dme_retrieve_res(device_index, addr, length, inf_res):
    """Request for retrieving dme result.

    Returns 0 on success and error code on failure.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        addr: DDR address to retrieve.
        length: Size of data to retrieve.
        inf_res: Contains retrieving result.
    """
    c_function = LIB.kdp_dme_retrieve_res
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint, ctypes.c_int, ctypes.c_char_p]
    c_function.restype = ctypes.c_int
    return c_function(device_index, addr, length, inf_res)

def kdp_dme_get_status(device_index, ssid, status, inf_size, inf_res):
    """Request for getting DME inference status.

    Returns 0 on success and error code on failure. Also returns the new values of ssid,
    status, and inf_size.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
        ssid: SSID to get inference status.
        status: Inference status, 0 for not ready and 1 for ready
        inf_size: Inference data size.
        inf_res: Inference result data.
    """
    c_function = LIB.kdp_dme_get_status
    c_function.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint),
                           ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint),
                           ctypes.c_char_p]
    ssid_p = ctypes.c_uint(ssid)
    status_p = ctypes.c_uint(status)
    inf_size_p = ctypes.c_uint(inf_size)
    c_function.restype = ctypes.c_int
    ret = c_function(device_index, ctypes.pointer(ssid_p), ctypes.pointer(status_p),
                     ctypes.pointer(inf_size_p), inf_res)
    return ret, ssid_p.value, status_p.value, inf_size_p.value

def kdp_end_dme(device_index):
    """Request for ending dme mode.

    Returns 0 on succeed, else for error code.

    Arguments:
        device_index: Connected device ID. A host can connect several devices.
    """
    c_function = LIB.kdp_end_dme
    c_function.argtypes = [ctypes.c_int, ctypes.c_uint]
    c_function.restype = ctypes.c_int
    return c_function(device_index, 255)
